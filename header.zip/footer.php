 <?php 
 echo'<p>&copy; 2014 manish434k@yahoo.com. All rights reserved.</p>';
 ?>