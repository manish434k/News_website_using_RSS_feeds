<?php
 echo '<div class="list">
 <a href="index.php">Top stories</a>
 <div>
 <ul>
 <li><a href="timesofindia.php" >The Times Of India</a></li>
 <li><a href="thehindu.php" >The Hindu</a></li>
 <li><a href="ndtv.php" >NDTV</a></li>
  <li><a href="hindustantimes.php" >Hindustan Times</a></li>
 </ul>
 </div>
 </div>';
 echo '<div class="list">
 <a href="bollywood.php">Bollywood Stories</a>
 </div>';
?>