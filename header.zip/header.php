 <?php 
 echo'<link rel="shortcut icon" href="webicon.ico">
 <div class="header-cont">
 <a href="index.php"><img src="images/newslogo.png" alt="logo" /></a>
 </div>';
 ?>